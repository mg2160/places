module PlacesHelper
end
